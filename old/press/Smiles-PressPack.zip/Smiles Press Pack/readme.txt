
- Smiles for iPhone Press Pack -------------------------------------------------

Released: October 30th, 2008

- ------------------------------------------------------------------------------

Hi there,

This is the "Smiles" press pack.  Several full and high resolution images
suitable for promoting the game "Smiles", available for iPhone and iPod touch.

The press pack includes:
- 14 screen shots
- High resolution "Smiles" Logo
- High resolution "Sykhronics Entertainment" Logo
- High resolution Icon
- High resolution rounded Icon
- High resolution Artwork

Video will be available in the next few days.

If you have any questions, or require higher resolution image for print or
broadcast use, feel free to contact Mike at "information@sykhronics.com".


Thanks,

Mike Kasprzak
Sykhronics Entertainment

www.sykhronics.com
www.smiles-game.com

- ------------------------------------------------------------------------------
